LIBRARY ieee;
USE ieee.std_logic_1164.all;

ENTITY FSM IS
	PORT(reset, clk, data_in: IN STD_LOGIC;
		  student_id, current_state: OUT STD_LOGIC_VECTOR(3 DOWNTO 0));
END FSM;

ARCHITECTURE Behavior OF FSM IS
    TYPE state_type IS (s0, s1, s2, s3, s4, s5, s6, s7, s8);
    SIGNAL y : state_type;
BEGIN
    PROCESS (clk, reset)
    BEGIN
        IF reset = '0' THEN
            y <= s0;
        ELSIF (clk'EVENT AND clk = '1') THEN 
            CASE y is
                WHEN s0 => IF data_in='1' THEN y<=s1; ELSE y<=s0; END IF;
                WHEN s1 => IF data_in='1' THEN y<=s2; ELSE y<=s1; END IF;
                WHEN s2 => IF data_in='1' THEN y<=s3; ELSE y<=s2; END IF;
                WHEN s3 => IF data_in='1' THEN y<=s4; ELSE y<=s3; END IF;
                WHEN s4 => IF data_in='1' THEN y<=s5; ELSE y<=s4; END IF;
                WHEN s5 => IF data_in='1' THEN y<=s6; ELSE y<=s5; END IF;
                WHEN s6 => IF data_in='1' THEN y<=s7; ELSE y<=s6; END IF;
                WHEN s7 => IF data_in='1' THEN y<=s8; ELSE y<=s7; END IF;
                WHEN s8 => IF data_in='1' THEN y<=s0; ELSE y<=s8; END IF;
				END CASE;
        END IF;
    END PROCESS;
	 
    PROCESS(y)
    BEGIN
        CASE y IS
            WHEN s0 => current_state <= "0000"; student_id <= "0101"; 
            WHEN s1 => current_state <= "0001"; student_id <= "0000"; 
            WHEN s2 => current_state <= "0010"; student_id <= "0001"; 
            WHEN s3 => current_state <= "0011"; student_id <= "0010"; 
            WHEN s4 => current_state <= "0100"; student_id <= "1000"; 
            WHEN s5 => current_state <= "0101"; student_id <= "1000"; 
            WHEN s6 => current_state <= "0110"; student_id <= "1000";
            WHEN s7 => current_state <= "0111"; student_id <= "0000"; 
            WHEN s8 => current_state <= "1000"; student_id <= "0101"; 
        END CASE;
    END PROCESS;
END ARCHITECTURE;
