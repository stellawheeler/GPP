LIBRARY ieee;
USE ieee.std_logic_1164.all;
USE ieee.std_logic_unsigned.all;

ENTITY sseg2 IS
	PORT(bcd: IN STD_LOGIC_VECTOR(3 DOWNTO 0);
			led1: OUT STD_LOGIC_VECTOR(1 TO 7));
END sseg2;

ARCHITECTURE Behavior OF sseg2 IS
	SIGNAL Sum: STD_LOGIC_VECTOR(4 DOWNTO 0);
BEGIN
	PROCESS(bcd)
	BEGIN
	CASE bcd IS
		WHEN "1111" => led1 <= not"0110011";--y
		WHEN "0000" => led1 <= not"1110110";--N
		WHEN OTHERS => led1 <= not"0000000";
	END CASE;
	END PROCESS;
END Behavior;

