library verilog;
use verilog.vl_types.all;
entity part1_vlg_check_tst is
    port(
        R_First4        : in     vl_logic_vector(0 to 6);
        R_Last4         : in     vl_logic_vector(0 to 6);
        RNEG_First4     : in     vl_logic_vector(0 to 6);
        RNEG_Last4      : in     vl_logic_vector(0 to 6);
        StudentId_Display: in     vl_logic_vector(0 to 6);
        sampler_rx      : in     vl_logic
    );
end part1_vlg_check_tst;
