library verilog;
use verilog.vl_types.all;
entity part1 is
    port(
        R_First4        : out    vl_logic_vector(0 to 6);
        clock           : in     vl_logic;
        reset           : in     vl_logic;
        A               : in     vl_logic_vector(7 downto 0);
        B               : in     vl_logic_vector(7 downto 0);
        Enable_Decoder  : in     vl_logic;
        data_inFSM      : in     vl_logic;
        R_Last4         : out    vl_logic_vector(0 to 6);
        RNEG_First4     : out    vl_logic_vector(0 to 6);
        RNEG_Last4      : out    vl_logic_vector(0 to 6);
        StudentId_Display: out    vl_logic_vector(0 to 6)
    );
end part1;
