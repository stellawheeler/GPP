library verilog;
use verilog.vl_types.all;
entity part2_vlg_sample_tst is
    port(
        A               : in     vl_logic_vector(7 downto 0);
        B               : in     vl_logic_vector(7 downto 0);
        clock           : in     vl_logic;
        data_inFSM      : in     vl_logic;
        Enable_Decoder  : in     vl_logic;
        reset           : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end part2_vlg_sample_tst;
