library verilog;
use verilog.vl_types.all;
entity dec4to16 is
    port(
        y               : out    vl_logic_vector(15 downto 0);
        w               : in     vl_logic_vector(3 downto 0);
        en              : in     vl_logic
    );
end dec4to16;
