LIBRARY ieee;
USE ieee.std_logic_1164.all;
USE ieee.std_logic_unsigned.all;

ENTITY sseg IS
	PORT(sign: IN STD_LOGIC;
			bcd: IN STD_LOGIC_VECTOR(3 DOWNTO 0);
			led1, led2: OUT STD_LOGIC_VECTOR(1 TO 7));
END sseg;

ARCHITECTURE Behavior OF sseg IS
	SIGNAL Sum: STD_LOGIC_VECTOR(4 DOWNTO 0);
BEGIN
	PROCESS(bcd)
	BEGIN
	IF (sign='1') THEN
		led1 <= NOT"0000001";
	ELSE
		led1 <= NOT"0000000";
	END IF;
	CASE bcd IS
		WHEN "0000" => led2 <= not"1111110";
		WHEN "0001" => led2 <= not"0110000";
		WHEN "0010" => led2 <= not"1101101";
		WHEN "0011" => led2 <= not"1111001";
		WHEN "0100" => led2 <= not"0110011";
		WHEN "0101" => led2 <= not"1011011";
		WHEN "0110" => led2 <= not"1011111";
		WHEN "0111" => led2 <= not"1110000";
		WHEN "1000" => led2 <= not"1111111";--8
		WHEN "1001" => led2 <= not"1111011";--9
		WHEN "1010" => led2 <= not"1110111";--A
		WHEN "1011" => led2 <= not"0011111";--B
		WHEN "1100" => led2 <= not"1001110";--C
		WHEN "1101" => led2 <= not"0111101";--D
		WHEN "1110" => led2 <= not"1001111";--E
		WHEN "1111" => led2 <= not"1000111";--F
	END CASE;
	END PROCESS;
END Behavior;
